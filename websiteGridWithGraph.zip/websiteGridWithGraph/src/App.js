import React from "react";
import Home from "./layout/Home";
function App() {
  return (
    <>
     <Home/>
    </>
  )
}
export default App;